"""Version module to be read from various places"""
__version__ = "1.0.10"  # pragma: no cover
